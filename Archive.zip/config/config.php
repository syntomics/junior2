<?php

error_reporting(1);

$base_url = 'http://localhost/polovni_automobili';

$hostname = 'localhost';
$database = 'pa_db';
$username = 'root';
$password = 'root';

$conn = new mysqli($hostname, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>