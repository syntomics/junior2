<form method="post" action="../functions/add_car.php">
	<input type="text" name="brand">
	<input type="text" name="model">	
	<input type="number" name="year" min="1999" >
	<input type="text" name="price">
	<input type="submit" name="" value="save">



</form>