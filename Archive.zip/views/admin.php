<?php include('../config/config.php'); ?>

<hr>

	<a href="add_car.php"> ADD CAR </a>

<hr>

<table border="2">
	<tr>
		<th>Brand/Model</th>
		<th>Year</th>
		<th>Price</th>
		<th>X</th>
	</tr>

	<?php

		$sql = "SELECT * FROM cars WHERE status = 1";
		$car_offers = $conn->query($sql);

		if ($car_offers->num_rows > 0) {
		    // output data of each row
		    while($row = $car_offers->fetch_assoc()) {
		        echo "<tr>";
		        echo "<td>".$row['brand']." - ".$row['model']."</td>";
		        echo "<td>Year: " . $row['year']."</td>";
		        echo "<td><em>".$row['price']."</em></td>";
		        echo "<td><a href='../functions/delete_car.php?id=".$row['id']."' > X </a></td>";
		        echo "</tr>";
		    }
		} else {
		    echo "0 cars in database";
		}

	?>

</table>