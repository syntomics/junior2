<?php include('../config/config.php'); ?>

<hr>
<a href="<?php echo $base_url; ?>">Home</a>

<a href="<?php echo $base_url; ?>/views/about.php">About</a>

<a href="<?php echo $base_url; ?>/views/contact.php">Contact</a>

<a style="float: right;" href="<?php echo $base_url; ?>/views/admin.php">Admin</a>

<hr>

<h3>My recent used cars</h3>

<ul>

	<?php

	$sql = "SELECT * FROM cars WHERE status = 1";
	$car_offers = $conn->query($sql);

	if ($car_offers->num_rows > 0) {
	    // output data of each row
	    while($row = $car_offers->fetch_assoc()) {
	        echo "<li>";
	        echo "<strong>".$row['brand']." - ".$row['model']."</strong>";
	        echo "<p>Year: " . $row['year']."</p>";
	        echo "<p><em>".$row['price']."</em></p>";
	        echo "<a href='' >BUY</a>";
	        echo "</li>";
	    }
	} else {
	    echo "0 cars";
	}

	?>
	
</ul>

