<?php 
include("../config/config.php");

$sql = "INSERT INTO cars ( brand, model, year, price) 
		VALUES ('". $_POST[ 'brand' ]."', '". $_POST[ 'model' ]."', '". $_POST[ 'year' ]."', '". $_POST[ 'price' ]."' )";
$conn->query($sql);

header('Location: ../views/admin.php'); 

 ?>