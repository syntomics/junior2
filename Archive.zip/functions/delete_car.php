<?php 
include ('../config/config.php');

$id = $_GET['id'];

$sql = "UPDATE cars SET status = 0 WHERE id = '".$id."' ";

$conn->query($sql);

header('Location: ../views/admin.php'); 

?>

